package com.example.library.user.member;
import org.springframework.data.repository.CrudRepository;



public interface UserRepository extends CrudRepository<User,Integer>{
}
